package td1.refactoring.api.burger;

public interface Product {
    double weight();
    double price();
}
