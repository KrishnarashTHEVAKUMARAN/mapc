package td1.refactoring.api.burger;

public interface DieteticElement {
    double calories_per_100g();
}
