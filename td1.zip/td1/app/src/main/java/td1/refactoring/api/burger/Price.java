package td1.refactoring.api.burger;

public enum Price {
    CHEAP, EXPENSIVE;
}
