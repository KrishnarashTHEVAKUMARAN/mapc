package td1.refactoring.api.burger;

public enum MenuSize {
    SMALL, MEDIUM, BIG;
}
