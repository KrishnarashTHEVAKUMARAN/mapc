package td1.refactoring.api.burger;

public enum MenuType {
    MEAT_MENU, FISH_MENU, CHEESE_MENU
}
