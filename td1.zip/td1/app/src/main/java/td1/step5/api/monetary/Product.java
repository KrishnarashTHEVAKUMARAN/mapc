package td1.step5.api.monetary;

public interface Product {
    double price();
}
