package td1.step5.api.dietetic;

public interface DieteticElement {
    double calories_per_100g();
}