package td1.step4.api.monetary;

public interface Product {
    double price();
}
