package td1.step4.api.burger;

public enum MenuType {
    MEAT_MENU, FISH_MENU, CHEESE_MENU;
}
