package td1.step4.api.burger;

import td1.step4.api.restauration.Recipe;

public class Burger extends Recipe {
    Burger(String name) {
        super(name);
    }
}
