package td1.step4.api.restauration;

public interface ComposedFood extends Food {
    void add(Base base, double weight);
}
