package td1.step1.api.general;

public interface Product {
    double weight();
    double price();
}
