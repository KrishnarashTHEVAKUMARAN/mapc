package td1.step1.api.general;

public interface Food {
    double calories_per_100g();
}
