package td1.step2.api.money;

public interface Product {
    double price();
}
