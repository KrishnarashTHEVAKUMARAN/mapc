package td1.step2.api.food;

public interface Food {
    double calories_per_100g();
}
