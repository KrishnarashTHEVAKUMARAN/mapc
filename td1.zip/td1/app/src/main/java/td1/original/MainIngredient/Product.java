package td1.original.MainIngredient;

public interface Product {
    double weight();

    double price();
}
