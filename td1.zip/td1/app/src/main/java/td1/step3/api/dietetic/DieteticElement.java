package td1.step3.api.dietetic;

public interface DieteticElement {
    double calories_per_100g();
}
