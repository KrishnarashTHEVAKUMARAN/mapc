package td1.step3.api.monetary;

public interface Product {
    double price();
}
